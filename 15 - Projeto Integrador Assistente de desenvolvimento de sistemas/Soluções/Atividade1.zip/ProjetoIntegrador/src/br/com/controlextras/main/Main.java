package br.com.controlextras.main;

import br.com.controlextras.modelos.Coordenador;
import br.com.controlextras.modelos.Funcionario;
import br.com.controlextras.modelos.HoraExtra;
import br.com.controlextras.modelos.ListaUsuario;
import br.com.controlextras.modelos.Usuario;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


public class Main {
    /*As horas extras disponiveis para todos*/
    static List<HoraExtra> horasExtrasDisponiveis = new ArrayList<>();
    
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static DateTimeFormatter dataFormatada = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
    public static void main(String[] args) {
        /* Criar Horas Extras*/
        Coordenador c1 = new Coordenador();
        c1.setNome("Aislan coordenador");
        c1.setId(200);
        c1.setDataNascimento(LocalDate.of(1987, Month.APRIL, 24));
        c1.setCpf("000.000.000-00");
        c1.setSalario(7000.00);
        cadastraHoraExtra(c1, "19/10/2024", "01:30", "08:30");
        cadastraHoraExtra(c1, "20/10/2024", "09:11", "09:32");
        
        Coordenador c2 = new Coordenador();
        c2.setNome("Jose coordenador");
        c2.setId(300);
        c2.setDataNascimento(LocalDate.of(1985, Month.JANUARY, 15));
        c2.setCpf("111.111.111-11");
        c2.setSalario(6500.00);
        cadastraHoraExtra(c2, "21/10/2024", "03:30", "08:30");
        cadastraHoraExtra(c2, "22/10/2024", "04:30", "08:30");
        
        /*verifica as horas disponíveis*/
        System.out.println(ANSI_RED + "----------------------------------------");
        System.out.println(ANSI_RED + "\tHORA EXTRAS - ANTES");
        System.out.println("----------------------------------------" + ANSI_RESET);
        for(HoraExtra he: horasExtrasDisponiveis) { 
            he.detalhe();
        }
        
        /*Inscrevi na hora extra*/
        Funcionario f1 = new Funcionario();
        f1.setNome("Alex funcionario");
        f1.setId(100);
        f1.setDataNascimento(LocalDate.parse("24/04/1987", dataFormatada));
        f1.setCpf("999.999.999-99");
        
        System.out.println(inscreveHoraExtra(f1, 0) ? "OK! INSCRITO" : "NÃO INSCRITO");
        System.out.println(inscreveHoraExtra(f1, 0) ? "OK! INSCRITO" : "NÃO INSCRITO");
        //System.out.println(inscreveHoraExtra(f1, 0) ? "OK" : "NÃO INSCRITO");
        //System.out.println(inscreveHoraExtra(f1, 0) ? "OK" : "NÃO INSCRITO");
        //System.out.println(inscreveHoraExtra(f1, 0) ? "OK" : "NÃO INSCRITO"); /*Só tem 4 HE*/
        
        
        /*verifica as horas disponíveis, depois de se inscreverem*/
        System.out.println(ANSI_BLUE + "----------------------------------------");
        System.out.println(ANSI_BLUE + "\tHORA EXTRAS - DEPOIS");
        System.out.println(ANSI_BLUE + "----------------------------------------" + ANSI_RESET);
        for(HoraExtra he: horasExtrasDisponiveis) {
            he.detalhe();
        }
        
        /*Mostrar o detalhes do Funcionário incluindo as HE deste*/
        Funcionario f2 = new Funcionario();
        f2.setNome("Gustavo funcionario");
        f2.setId(400);
        f2.setDataNascimento(LocalDate.of(1990, Month.DECEMBER, 2));
        f2.setCpf("222.222.222-22");
        f2.setSalario(3500.00);
        
        Coordenador cteste = new Coordenador();
        cteste.setId(f1.getId());
        cteste.setNome("Funcionario alterado para Coordenador");
        cteste.sethoraExtras(f1.gethoraExtras());
        cteste.setDataNascimento(f1.getDataNascimento());
        cteste.setCpf(f1.getCpf());
        cteste.setSalario(4500.00);
        
        /*Adiciona os funcionários na lista*/
        ListaUsuario.Adicionar(c1);
        ListaUsuario.Adicionar(c2);
        ListaUsuario.Adicionar(f1);
        ListaUsuario.Adicionar(f2);
        
        /*Lista de usuários*/
        System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
        for(Usuario u: ListaUsuario.Listar()){
           u.detalhes();
        }
        
        /*Edita usuário>> Através do ID*/
        ListaUsuario.Editar(cteste);
        
        // Mostra todos os usuários, incluindo o editado
        System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
        for(Usuario u: ListaUsuario.Listar()){
           u.detalhes();
        }
    }

    private static void cadastraHoraExtra(Coordenador c1, String dataHoraExtra, String horaInicio, String horaFim) {
        if(c1.isAtivo()) {
            LocalDate data = LocalDate.parse(dataHoraExtra, dataFormatada);
            LocalTime inicio = LocalTime.parse(horaInicio);
            LocalTime fim = LocalTime.parse(horaFim);
            HoraExtra he = c1.cadastrarHoraExtra(data, inicio, fim);
            
            if(he != null){
                horasExtrasDisponiveis.add(he);
            }
        } 
    }
    
    private static boolean inscreveHoraExtra(Funcionario f1, int posicao) {
        if(f1.isAtivo()) {
            int tamanho = horasExtrasDisponiveis.size();
            if(tamanho > 0){
                f1.inscreverHoraExtra(horasExtrasDisponiveis.get(posicao));
                horasExtrasDisponiveis.remove(posicao);
                return true;
            }
        }
        return false;
    }
}
