package br.com.controlextras.modelos;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class HoraExtra {
    private LocalDate data;
    private LocalTime horaInicio;
    private LocalTime horaFim;
    private Usuario criador;
    
    public HoraExtra(LocalDate data, LocalTime horaInicio, LocalTime horaFim, Usuario usuario) {
        this.data = data;
        this.horaInicio = horaInicio;
        this.horaFim = horaFim;
        this.criador = usuario;
    }
    public HoraExtra(){
        
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalTime getHoraFim() {
        return horaFim;
    }

    public void setHoraFim(LocalTime horaFim) {
        this.horaFim = horaFim;
    }
    
    public Usuario getCriador() {
        return criador;
    }

    public void setCriador(Usuario criador) {
        this.criador = criador;
    }
    
    public void detalhe() {
        String ANSI_RESET = "\u001B[0m";
        String ANSI_GREEN = "\u001B[32m";
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String dataFormatada = this.getData().format(formatter);
        System.out.println("****************************************");
        System.out.println("\tData: " + dataFormatada);
        System.out.println("\t" + this.getHoraInicio() + " - " + this.getHoraFim());
        System.out.println("\tCriada por: " + ANSI_GREEN + this.getCriador().getNome() + ANSI_RESET);
        System.out.println("****************************************");
    }
}
