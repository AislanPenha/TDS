package br.com.controlextras.modelos;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

public class Coordenador extends Funcionario{
    public HoraExtra cadastrarHoraExtra(LocalDate data, LocalTime horaEntrada, LocalTime horaSaida){
        Duration duracao = Duration.between(horaEntrada, horaSaida);
        HoraExtra horaExtra = null;
        if(duracao.toMinutes() > 0) {
            horaExtra = new HoraExtra(data, horaEntrada, horaSaida, this);
        }
        return horaExtra;
    }
}
