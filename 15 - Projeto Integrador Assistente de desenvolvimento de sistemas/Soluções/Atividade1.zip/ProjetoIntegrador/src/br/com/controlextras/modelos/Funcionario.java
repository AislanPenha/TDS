package br.com.controlextras.modelos;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Funcionario extends Usuario{
    private List<HoraExtra> horasExtras;
    public Funcionario() {
        horasExtras = new ArrayList<>();
    }
    
    public void sethoraExtras(List<HoraExtra> he) {
        this.horasExtras = he;
    }
    
    public List<HoraExtra> gethoraExtras() {
        return horasExtras;
    }
    @Override
    public void detalhes() {
        System.out.println("----------------------------------------");
        System.out.println("ID: " + this.getId());
        System.out.println("Nome: " + this.getNome());
        DateTimeFormatter formatterNasc = DateTimeFormatter.ofPattern("dd/MM/yyyy");
         String dataFormatadaNasc = "";
        if(this.getDataNascimento() != null){
            dataFormatadaNasc = this.getDataNascimento().format(formatterNasc);
        }
        System.out.println("Data de nascimento: " + dataFormatadaNasc);
        System.out.println("CPF: " + this.getCpf());
        System.out.println("Salario: " + this.getSalario());
        System.out.println("Status: " + this.isAtivo());
        
        if(!horasExtras.isEmpty()){
            System.out.println("HORAS EXTRAS");
            for(HoraExtra he: horasExtras){
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                String dataFormatada = he.getData().format(formatter);
                System.out.println("\t *" + dataFormatada);
            }
        }
        System.out.println("----------------------------------------");
    }
    
    public void inscreverHoraExtra(HoraExtra horaExtra){
        horasExtras.add(horaExtra);
    }
}
