package br.com.controlextras.modelos;

import java.time.LocalDate;

public abstract class Usuario {
    private int id;
    private String nome;
    private LocalDate dataNascimento;
    private String cpf;
    private Double salario;
    private boolean ativo;
    
    public Usuario(){
        this.ativo = true;
    }
    public Usuario(int id, String nome, LocalDate dataNascimento, String cpf, Double salario) {
        this.id = id;
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.cpf = cpf;
        this.salario = salario;
        this.ativo = true;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }
    
    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
    
    public boolean isAtivo() {
        return ativo;
    }
    
    public void detalhes() {
        System.out.println("----------------------------------------");
        System.out.println("ID: " + id);
        System.out.println("Nome: " + nome);
        
        System.out.println("Data de nascimento: " + dataNascimento);
        System.out.println("CPF: " + cpf);
        System.out.println("Salario: " + salario);
        System.out.println("Status: " + ativo);
        System.out.println("----------------------------------------");
    }
}
