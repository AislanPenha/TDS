package br.com.controlextras.modelos;

import java.util.ArrayList;
import java.util.List;


public class ListaUsuario {
    private static final List<Usuario> usuarios = new ArrayList<>();
    
    private static int posicaoUsuario(int id) {
        int posicao = -1;
        for(int i=0; i< usuarios.size(); i++) {
              if(usuarios.get(i).getId() == id){
                  posicao = i;
              }
          }
        return posicao;
    }
    public static List<Usuario> Listar(){
        return usuarios;
    }
    
    public static void Adicionar(Usuario usuario) {
        usuarios.add(usuario);
    }
    
    public static void Editar(Usuario usuario) {
        int posicao = posicaoUsuario(usuario.getId());
        if(posicao != -1) {
            usuarios.set(posicao, usuario);
        }
    }
    
    public static void Remover(Usuario usuario) {
        usuarios.remove(usuario.getId());
    }
  
}
