package br.com.controlextras.modelos;

public class Gerente extends Coordenador{
    
    public void criarUsuario(Usuario usuario) {
        ListaUsuario.Adicionar(usuario);
    }
    
    public void editarUsuario(Usuario usuario) {
        
        ListaUsuario.Editar(usuario);
    }
    
    public void excluirUsuario(Usuario usuario) {
        ListaUsuario.Remover(usuario);
    }
}
