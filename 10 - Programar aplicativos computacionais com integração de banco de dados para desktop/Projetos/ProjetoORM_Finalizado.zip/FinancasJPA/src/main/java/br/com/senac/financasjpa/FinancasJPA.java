package br.com.senac.financasjpa;

import br.com.senac.financasjpa.persistencia.Despesa;
import br.com.senac.financasjpa.persistencia.DespesaDAO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.time.LocalDate;

public class FinancasJPA {

    public static void main(String[] args) {
        EntityManagerFactory fabricaEntidade = Persistence.createEntityManagerFactory("Financas-PU");
        EntityManager manager = fabricaEntidade.createEntityManager();
        
       

        manager.close();
        fabricaEntidade.close();
    }
}
