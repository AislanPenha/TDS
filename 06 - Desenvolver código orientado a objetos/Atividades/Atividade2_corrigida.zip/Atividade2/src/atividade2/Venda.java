package atividade2;

import java.text.NumberFormat;
import java.util.Locale;

public class Venda {
    private String cliente;
    private String formaDePagamento;
    private PacoteViagem pacote;
    private float cotacaoDoDolar;
    public Venda(String cliente, String formaDePagamento, PacoteViagem pacote, float cotacao) {
        this.cliente = cliente;
        this.formaDePagamento = formaDePagamento;
        this.pacote = pacote;
        this.cotacaoDoDolar = cotacao; // valor do dólar na data atual
    }
    
    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getFormaPagamento() {
        return formaDePagamento;
    }

    public void setFormaPagamento(String forma) {
        this.formaDePagamento = forma;
    }

    public PacoteViagem getPacote() {
        return pacote;
    }

    public void setPacote(PacoteViagem pacote) {
        this.pacote = pacote;
    }
    
    public float getCotacao() {
        return cotacaoDoDolar;
    }

    public void setCotacao(float cotacao) {
        this.cotacaoDoDolar = cotacao;
    }
    
    public float convertMoeda(float valor, float cotacao) {
        return valor * cotacao;
    }
    
    /*mostrar na tela o total do pacote de viagem em dólar e em reais.*/
    public float totalEmDolar(float lucro) {
        float total;
        total = pacote.totalPacote(pacote.totalLucro(lucro, pacote.totalHospedagem()));
        return total;
    }
    public float totalEmReal(float lucro) {
        return this.convertMoeda(this.totalEmDolar(lucro), this.cotacaoDoDolar);
    }
    
    public void status(float lucro) {
        System.out.println("-----------------------------------------------------");
        System.out.println("O cliente " + this.cliente + " pagará na forma de "
                    + this.formaDePagamento);
        System.out.println("Sua viagem para " + this.pacote.getDestino());
        System.out.println("No " + this.pacote.getHospedagem().getDescricao());
        System.out.println("No intervalor de " + this.pacote.getDias() + " dias");
        System.out.println("No transporte " + this.pacote.getTransporte().getTipo());
        System.out.println("TOTAL EM DOLAR: " + NumberFormat.getCurrencyInstance(Locale.US).format(this.totalEmDolar(0)));
        System.out.println("TOTAL EM REAL: " + NumberFormat.getCurrencyInstance(new Locale("pt", "BR")).format(this.totalEmReal(0)));
        System.out.println("TOTAL EM DOLAR COM LUCRO("+lucro+"%): " + NumberFormat.getCurrencyInstance(Locale.US).format(this.totalEmDolar(lucro)));
        System.out.println("TOTAL EM REAL COM LUCRO("+lucro+"%): " + NumberFormat.getCurrencyInstance(new Locale("pt", "BR")).format(this.totalEmReal(lucro)));
        System.out.println("DÓLAR: " + NumberFormat.getCurrencyInstance(Locale.US).format(this.cotacaoDoDolar));
    }
}
