package atividade2;

import java.util.ArrayList;
import java.util.List;
import tela.Tela;

public class Atividade2 {

    public static void main(String[] args) {
        String opcao;
        Tela tela = new Tela();
        List<Transporte> transportes = new ArrayList<>();
        List<Hospedagem> hospedagens = new ArrayList<>();
        List<PacoteViagem> pacotes = new ArrayList<>();
        List<Venda> vendas = new ArrayList<>();
        while(true) {
            opcao = tela.telaPrincipal();
            switch(opcao) {
            case "1" -> transportes.add(tela.telaTransporte());
            case "2" -> hospedagens.add(tela.telaHospedagem());
            case "3" -> {
                if(transportes.isEmpty()){
                    System.out.println("Adicione pelo menos 1 transporte!");
                }
                if(hospedagens.isEmpty()){
                    System.out.println("Adicione pelo menos 1 hospedagem!");
                }
                if((!transportes.isEmpty()) && (!hospedagens.isEmpty())) {
                    Transporte transporte;
                    Hospedagem hospedagem;
                    transporte = tela.telaTransporte(transportes);
                    if(transporte != null){
                        hospedagem = tela.telaHospedagem(hospedagens);
                        if(hospedagem != null){
                            pacotes.add(tela.telaPacote(transporte, hospedagem));
                        }
                    }
                }
                }
            case "4" -> {
                if(pacotes.isEmpty()){
                    System.out.println("Adicione pelo menos 1 pacote!");
                }else{
                    vendas.add(tela.telaVenda(pacotes));
                }
                }
            case "5" -> tela.telaTodasVenda(vendas);
            case "6" -> {
                tela.telaSair();
                System.exit(0);
                }
            default -> System.out.println("Opção inválida");
            }
            
        }
    }
    
}
