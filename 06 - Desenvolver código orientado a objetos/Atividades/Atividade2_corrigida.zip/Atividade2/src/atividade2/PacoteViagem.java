package atividade2;
/*
Observação: os valores nesta classe serão considerados em dólar.
*/
public class PacoteViagem {
    private Transporte transporte;
    private Hospedagem hospedagem;
    private String destino;
    private int dias;

    public PacoteViagem(Transporte transporte, Hospedagem hospedagem, String destino, int dias) {
        this.transporte = transporte;
        this.hospedagem = hospedagem;
        this.destino = destino;
        this.dias = dias;
    }
    
    public Transporte getTransporte() {
        return transporte;
    }

    public void setTransporte(Transporte transporte) {
        this.transporte = transporte;
    }

    public Hospedagem getHospedagem() {
        return hospedagem;
    }

    public void setHospedagem(Hospedagem hospedagem) {
        this.hospedagem = hospedagem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public int getDias() {
        return dias;
    }

    public void setDias(int dias) {
        this.dias = dias;
    }
    
    /*calcular o total de hospedagem a partir do número de dias e o valor da diária.*/
    public float totalHospedagem() {
        float total;
        total = this.getDias() * hospedagem.getValor();
        return total;
    }
    
    /*calcular valor de lucro a partir de uma margem informada (porcentagem) e valor informado. 
     * O resultado retornado deve ser o valor + margem aplicada ao valor. */
    public float totalLucro(float margem, float valor) {
        float total;
        total = margem / 100 * valor;
        return total;
    }
    
    /*calcular e retornar o total do pacote, somando o transporte, o total da hospedagem e
     * os valores adicionais informados – margem de lucro (porcentagem) e taxas adicionais (valor monetário).*/
    public float totalPacote(float lucro) {
        float total;
        total = transporte.getValor() + this.totalHospedagem() + lucro;
        return total;
    }

}
