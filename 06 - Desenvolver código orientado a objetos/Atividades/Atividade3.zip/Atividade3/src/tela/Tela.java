package tela;

import atividade3.Funcionario;
import atividade3.FuncionarioAssalariado;
import atividade3.FuncionarioHorista;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Tela {
    Scanner entrada = new Scanner(System.in);
    
    public void telaSair() {
        System.out.println("Volte sempre!!!!");
        entrada.close();
    }
    public String telaPrincipal() {
        String opcao;
        System.out.println("-----------------------------------------------------");
        System.out.println("-=-=-=-=-=-=-=-=- SETOR DO RH -=-=-=-=-=-=-=-=-");
        System.out.println("-----------------------------------------------------");
        System.out.println("[1] - Cadastrar o funcionário");
        System.out.println("[2] - Ver todos funcionários");
        System.out.println("[3] - Aumento Geral do Salário");
        System.out.println("[4] - Sair");
        
        System.out.print("Escolha uma opção: ");
        opcao = entrada.nextLine();
        return opcao;
    }
    public Funcionario telaFuncionario() {
        float salarioMensal, horasTrabalhada, valorHora;
        String nome, endereco, telefone, setor, tipo, cpf;
        Funcionario func;
        
        System.out.print("Qual o NOME do Funcionário: ");
        nome = entrada.nextLine();
        System.out.print("Qual o CPF do Funcionário: ");
        cpf = entrada.nextLine();
        System.out.print("Qual o ENDEREÇO do Funcionário: ");
        endereco = entrada.nextLine();
        System.out.print("Qual o TELEFONE do Funcionário: ");
        telefone = entrada.nextLine();
        System.out.print("Qual o SETOR do Funcionário: ");
        setor = entrada.nextLine();
        
        System.out.print("Qual o TIPO de Funcionário (A)ssalariado ou (H)orista (A ou H)? ");
        tipo = entrada.nextLine();
        if(tipo.equals("A")) {
            System.out.print("Qual o SALÁRIO MENSAL do Funcionário: R$");
            salarioMensal = entrada.nextFloat();
            func = new FuncionarioAssalariado(nome, cpf, endereco, telefone, setor, salarioMensal);            
        }else {
            System.out.print("Quantas HORAS TRABALHOU o Funcionário: ");
            horasTrabalhada = entrada.nextFloat();
            System.out.print("Qual o valor da HORA Trabalhada: R$");
            valorHora = entrada.nextFloat();
            func = new FuncionarioHorista(nome, cpf, endereco, telefone, setor, horasTrabalhada, valorHora);
        }
        
        System.out.println("Cadastrado com sucesso!");
        entrada.nextLine();
        return func;
    }
    public void telaAumentoGeral(List<Funcionario> funcionarios) {
        if(funcionarios.isEmpty()) {
            System.out.println("Sem funcionários :(");
        } else {
            float aumento;
            System.out.print("Qual será a PORCENTAGEM de AUMENTO %");
            aumento = entrada.nextFloat();
            for(Funcionario funcionario: funcionarios) {
                funcionario.calcularSalario(aumento);
            }
        }
    }
    public void telaTodosFuncionarios(List<Funcionario> funcionarios) {
        if(funcionarios.isEmpty()) {
            System.out.println("Sem funcionários :(");
        } else {
            for(Funcionario funcionario: funcionarios) {
                funcionario.status();
            }
        }
    }
    /*
    public Hospedagem telaHospedagem() {
        float valor;
        String descricao;
        System.out.print("Qual o DESCRIÇÃO da HOSPEDAGEM: ");
        descricao = entrada.nextLine();
        System.out.print("Qual o VALOR de HOSPEDAGEM: $");
        valor = entrada.nextFloat();
        
        Hospedagem hospedagem = new Hospedagem(descricao, valor);
        System.out.println("Cadastrado com sucesso!");
        entrada.nextLine();
        return hospedagem;
    }
    public Transporte telaTransporte(List<Transporte> transportes){
        int opcao;
        Transporte transporte;
        System.out.println("Escolha um TRANSPORTE");
        for (int i=0; i < transportes.size(); i++) {
            System.out.println("[" + (i+1) + "] - " + transportes.get(i).getTipo() + "\t" 
                    + NumberFormat.getCurrencyInstance(Locale.US).format(transportes.get(i).getValor()));
        }
        System.out.println("[0] - Para sair");
        System.out.print("Qual sua escolha: ");
        opcao = entrada.nextInt();
        if(opcao == 0) {
            transporte = null;
        } else {
            transporte = transportes.get(opcao - 1);
        }
        entrada.nextLine();
        return transporte;
    }
    public Hospedagem telaHospedagem(List<Hospedagem> hospedagens){
        int opcao;
        Hospedagem hospedagem;
        System.out.println("Escolha uma HOSPEDAGEM");
        for (int i=0; i < hospedagens.size(); i++) {
            System.out.println("[" + (i+1) + "] - " + hospedagens.get(i).getDescricao()+ "\t" 
                    + NumberFormat.getCurrencyInstance(Locale.US).format(hospedagens.get(i).getValor()));
        }
        System.out.println("[0] - Para sair");
        System.out.print("Qual sua escolha: ");
        opcao = entrada.nextInt();
        if(opcao == 0) {
            hospedagem = null;
        } else {
            hospedagem = hospedagens.get(opcao - 1);
        }
        entrada.nextLine();
        return hospedagem;
    }
    public PacoteViagem telaPacote(Transporte transporte, Hospedagem hospedagem) {
        int dias;
        String destino;
        System.out.print("Qual o DESTINO deste PACOTE: ");
        destino = entrada.nextLine();
        System.out.print("Quantos DIAS terá este PACOTE: ");
        dias = entrada.nextInt();

        PacoteViagem pacote = new PacoteViagem(transporte, hospedagem, destino, dias);
        System.out.println("Cadastrado com sucesso!");
        entrada.nextLine();
        return pacote;
    }
    public Venda telaVenda(List<PacoteViagem> pacotes){
        PacoteViagem pacote;
        Venda venda;
        String cliente, formaPagamento;
        float cotacao;
        pacote = telaPacotes(pacotes);
        if(pacote == null) {
            venda = null;
        } else{
            System.out.print("Qual o nome do cliente: ");
            cliente = entrada.nextLine();
            System.out.print("Qual a forma de pagamento: ");
            formaPagamento = entrada.nextLine();
            System.out.print("Qual o valor do DOLAR em Reais R$");
            cotacao = entrada.nextFloat();
            venda = new Venda(cliente, formaPagamento, pacote, cotacao);
            System.out.println("Cadastrado com sucesso!");
            entrada.nextLine();
        }

        return venda; 
    }
    public PacoteViagem telaPacotes(List<PacoteViagem> pacotes){
        int opcao;
        PacoteViagem pacote;
        System.out.println("Escolha um PACOTE");
        for (int i=0; i < pacotes.size(); i++) {
            System.out.println("[" + (i+1) + "] - " + pacotes.get(i).getDestino() 
                    + ". No " + pacotes.get(i).getHospedagem().getDescricao() + " em " + pacotes.get(i).getDias() + " dias.");
        }
        System.out.println("[0] - Para sair");
        System.out.print("Qual sua escolha: ");
        opcao = entrada.nextInt();
        if(opcao == 0) {
            pacote = null;
        } else {
            pacote = pacotes.get(opcao - 1);
        }
        entrada.nextLine();
        return pacote;
    }*/
    
}
