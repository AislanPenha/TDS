package atividade3;

public class FuncionarioHorista extends Funcionario{
    private float horasTrabalhada, valorHora;
    
    public float getHorasTrabalhada() {
        return horasTrabalhada;
    }

    public void setHorasTrabalhada(float horasTrabalhada) {
        this.horasTrabalhada = horasTrabalhada;
    }

    public float getValorHora() {
        return valorHora;
    }

    public void setValorHora(float valorHora) {
        this.valorHora = valorHora;
    }

    public FuncionarioHorista(String nome, String cpf, String endereco, String telefone, String setor, float horas, float valorHora) {
        super(nome, cpf, endereco, telefone, setor);
        this.horasTrabalhada = horas;
        this.valorHora = valorHora;
        this.setSalario(horas * valorHora);
    }

    @Override
    public void calcularSalario(float aumento) {
        float novaHora;
        novaHora = this.getValorHora() + this.getValorHora() * aumento /100;
        this.valorHora = novaHora;
        this.setSalario(this.horasTrabalhada * novaHora);
    }
    
    @Override
    public void status() {
        System.out.println("--------------------------------------");
        System.out.println("NOME: " + this.getNome());
        System.out.println("CPF: " + this.getCpf());
        System.out.println("Endereço: " + this.getEndereco());
        System.out.println("Telefone: " + this.getTelefone());
        System.out.println("Setor: " + this.getSetor());
        System.out.println("Horas trabalhada: " + this.getHorasTrabalhada());
        System.out.println("Valor Hora: " + this.getValorHora());
        System.out.println("Salário OFICIAL: " + this.getSalario());
        System.out.println("--------------------------------------");
    }
}
