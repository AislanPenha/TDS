package atividade3;

import java.util.ArrayList;
import java.util.List;
import tela.Tela;
public class Atividade3 {

    public static void main(String[] args) {
        List<Funcionario> funcionarios = new ArrayList<>();
        String opcao;
        Tela tela = new Tela();
        while(true) {
            opcao = tela.telaPrincipal();
            switch(opcao) {
                case "1" -> {
                    if(funcionarios.size() >= 10) {
                        System.out.println("Não podemos mais cadastrar!");
                    }else{
                        funcionarios.add(tela.telaFuncionario());
                    }
                }
                case "2" -> {
                    tela.telaTodosFuncionarios(funcionarios);
                }
                case "3" -> {
                    tela.telaAumentoGeral(funcionarios);
                }
                case "4" -> {
                    tela.telaSair();
                    System.exit(0);
                }
                default -> System.out.println("Opção inválida");
                }
            }
        
        /*
        
        FuncionarioAssalariado aislan = new FuncionarioAssalariado("Aislan", "123456789", "Vila Kiola", "98988404291", "PMMA", 5000);
        FuncionarioAssalariado catarina = new FuncionarioAssalariado("Catarina", "1010101010", "Araçagi", "9899932153", "Prefetura", 25000);
        FuncionarioHorista valdenilton = new FuncionarioHorista("Valdenilton", "88888888888", "Maceio", "8765656565", "Hostmart", 120, 50);
        funcionarios.add(aislan);
        funcionarios.add(catarina);
        funcionarios.add(valdenilton);
        for (int i=0; i < funcionarios.size(); i++) {
            funcionarios.get(i).status();
        }
        
        catarina.calcularSalario(10);
        valdenilton.calcularSalario(10);
        for (int i=0; i < funcionarios.size(); i++) {
            funcionarios.get(i).status();
        } */ 
    }
    
}
