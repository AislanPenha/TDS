package atividade3;

public class FuncionarioAssalariado extends Funcionario{
    private float salarioMensal;
    
    public FuncionarioAssalariado(String n, String cpf, String end, String tel, String setor, float sal) {
        super(n, cpf, end, tel, setor);
        this.salarioMensal = sal;
        this.setSalario(this.salarioMensal);
    }
    public void setSalarioMensal(float mensal) {
        this.salarioMensal = mensal;
    }
    public float getSalarioMensal() {
        return this.salarioMensal;
    }
    public void calcularSalario() {
        this.getSalario();
    }

    @Override
    public void calcularSalario(float aumento) {
        float novoSalario;
        novoSalario = this.getSalario() + this.getSalario()*aumento/100;
        salarioMensal = novoSalario;
        this.setSalario(novoSalario);
    }
    @Override
    public void status() {
        System.out.println("--------------------------------------");
        System.out.println("NOME: " + this.getNome());
        System.out.println("CPF: " + this.getCpf());
        System.out.println("Endereço: " + this.getEndereco());
        System.out.println("Telefone: " + this.getTelefone());
        System.out.println("Setor: " + this.getSetor());
        System.out.println("Salario MENSAL: " + this.getSalarioMensal());
        System.out.println("Salário OFICIAL: " + this.getSalario());
        System.out.println("--------------------------------------");
    }
}
