package tela;

import atividade4.Imposto;
import atividade4.ImpostoIpi;
import atividade4.ImpostoPis;
import java.util.List;
import java.util.Scanner;

public class Tela {
    Scanner entrada = new Scanner(System.in);
    
    public void telaSair() {
        System.out.println("Volte sempre!!!!");
        entrada.close();
    }
    public String telaPrincipal(String empresa) {
        String opcao;
        System.out.println("-----------------------------------------------------");
        System.out.println("-=-=-=-=-=-=-=-=- " + empresa + " -=-=-=-=-=-=-=-=-");
        System.out.println("-----------------------------------------------------");
        System.out.println("[1] - Cadastrar imposto");
        System.out.println("[2] - Ver todos impostos");
        System.out.println("[3] - Sair");
        
        System.out.print("Escolha uma opção: ");
        opcao = entrada.nextLine();
        return opcao;
    }
    public Imposto telaImposto() {
        String tipo;
        Imposto imposto;
        float debito, credito, juros;
        float produto, frete, seguro, outras, aliquota;
        System.out.println("Qual o TIPO de Imposto [P]IS (Programa de Integração Social) ou [I](Imposto sobre Produtos Industrializados)");
        System.out.println("Qual sua opção [P] ou [I]");
        tipo = entrada.nextLine();
        
        if(tipo.equals("P")) {
            System.out.print("Qual o valor total do DÉBITO R$");
            debito = entrada.nextFloat();
            System.out.print("Qual o valor total do CRÉDITO R$");
            credito = entrada.nextFloat();
            System.out.print("Qual o valor JUROS %");
            juros = entrada.nextFloat();
            imposto = new ImpostoPis(debito, credito, juros);
        }else {
            System.out.print("Qual o VALOR do produto R$");
            produto = entrada.nextFloat();
            System.out.print("Qual o VALOR do FRETE R$");
            frete = entrada.nextFloat();
            System.out.print("Qual o VALOR do SEGURO R$");
            seguro = entrada.nextFloat();
            System.out.print("Qual o VALOR das OUTRAS DESPESAS R$");
            outras = entrada.nextFloat();
            System.out.print("Qual o VALOR da ALÍQUOTA %");
            aliquota = entrada.nextFloat();
            imposto = new ImpostoIpi(aliquota, produto, frete, seguro, outras);
        }
        
        System.out.println("Cadastrado com sucesso!");
        entrada.nextLine();
        return imposto;
    }
    public void telaImpostos(List<Imposto> impostos){

        if(impostos.isEmpty()) {
            System.out.println("Nenhum imposto :)");
        } else {

            for(Imposto imposto: impostos) {
                imposto.tudo();
            }
        }
    }
    
}
