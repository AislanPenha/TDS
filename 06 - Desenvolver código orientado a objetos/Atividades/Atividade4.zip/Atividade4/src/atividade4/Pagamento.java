package atividade4;

import java.util.ArrayList;
import java.util.List;

public class Pagamento {
    private String nomeDaEmpresa;
    List<Imposto> impostos;
    
    public Pagamento(String nome) {
        this.nomeDaEmpresa = nome;
        impostos = new ArrayList<Imposto>();
    }
    public String getNomeDaEmpresa() {
        return this.nomeDaEmpresa;
    }
    public void adicionaImposto(Imposto i) {
        impostos.add(i);
    }
    public List<Imposto> getImpostos() {
        return this.impostos;
    }
}
