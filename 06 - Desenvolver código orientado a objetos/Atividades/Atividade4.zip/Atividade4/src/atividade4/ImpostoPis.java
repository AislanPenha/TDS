package atividade4;


public class ImpostoPis implements Imposto{
    private float totalDebito;
    private float valorCredito;
    private float percentual;
    private float totalPis;

    public ImpostoPis(float totalDebito, float valorCredito, float percentual) {
        this.totalDebito = totalDebito;
        this.valorCredito = valorCredito;
        this.percentual = percentual;
        this.calculaImposto();
    }
  
    @Override
    public void calculaImposto() {
        float total;
        total = (this.getTotalDebito() - this.getValorCredito()) * this.getPercentual()/100;
        this.setTotalPis(total);
    }

    public float getTotalDebito() {
        return totalDebito;
    }

    public void setTotalDebito(float totalDebito) {
        this.totalDebito = totalDebito;
    }

    public float getValorCredito() {
        return valorCredito;
    }

    public void setValorCredito(float valorCredito) {
        this.valorCredito = valorCredito;
    }

    public float getPercentual() {
        return percentual;
    }

    public void setPercentual(float percentual) {
        this.percentual = percentual;
    }

    public float getTotalPis() {
        return totalPis;
    }

    public void setTotalPis(float totalPis) {
        this.totalPis = totalPis;
    }

    @Override
    public void tudo() {
        System.out.println("PIS (Programa de Integração Social)");
        System.out.println("{Total do débito=" + totalDebito + ", valor do crédito=" + valorCredito + ", percentual=" + percentual + ", total do PIS=" + totalPis + '}');
    }
    
    
}
