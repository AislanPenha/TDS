package atividade4;

public class ImpostoIpi implements Imposto{
    private float aliquota;
    private float valorProduto, frete, seguro, outrasDespesas;
    private float totalIpi;
    
    public ImpostoIpi(float aliquota, float valorProduto, float frete, float seguro, float outrasDespesas) {
        this.setValorProduto(valorProduto);
        this.setAliquota(aliquota);
        this.setFrete(frete);
        this.setSeguro(seguro);
        this.setOutrasDespesas(outrasDespesas);
        this.calculaImposto();
    }

    public float getAliquota() {
        return aliquota;
    }

    public void setAliquota(float aliquota) {
        this.aliquota = aliquota;
    }

    public float getValorProduto() {
        return valorProduto;
    }

    public void setValorProduto(float valorProduto) {
        this.valorProduto = valorProduto;
    }

    public float getFrete() {
        return frete;
    }

    public void setFrete(float frete) {
        this.frete = frete;
    }

    public float getSeguro() {
        return seguro;
    }

    public void setSeguro(float seguro) {
        this.seguro = seguro;
    }

    public float getOutrasDespesas() {
        return outrasDespesas;
    }

    public void setOutrasDespesas(float outrasDespesas) {
        this.outrasDespesas = outrasDespesas;
    }
    public float getTotalIpi() {
        return totalIpi;
    }

    public void setTotalIpi(float total) {
        this.totalIpi = total;
    }
    
    @Override
    public void calculaImposto() {
        float valor;
        valor = (this.getValorProduto() + this.getFrete() + this.getSeguro() + this.getOutrasDespesas()) * this.getAliquota()/100;
        this.setTotalIpi(valor);
    }

    @Override
    public void tudo() {
        System.out.println("IPI (Imposto sobre Produtos Industrializados)");
        System.out.println("{Alíquota=" + aliquota + ", valor do produto=" + valorProduto + ", frete=" + frete + ", seguro=" + seguro + ", outras despesas=" + outrasDespesas + ", total do IPI=" + totalIpi + '}');
    }
    
}
