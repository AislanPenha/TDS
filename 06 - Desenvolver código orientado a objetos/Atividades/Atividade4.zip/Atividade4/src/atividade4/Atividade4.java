
package atividade4;

import tela.Tela;

public class Atividade4 {

    public static void main(String[] args) {
        Pagamento newLance = new Pagamento("NEW Lance S/A");
        Imposto imposto;
        String opcao;
        
        Tela tela = new Tela();
        while(true) {
            opcao = tela.telaPrincipal(newLance.getNomeDaEmpresa());
            switch(opcao) {
                case "1" -> {
                    imposto = tela.telaImposto();
                    newLance.adicionaImposto(imposto);
                }
                case "2" -> {
                    tela.telaImpostos(newLance.getImpostos());
                }
                case "3" -> {
                    tela.telaSair();
                    System.exit(0);
                }
                default -> System.out.println("Opção inválida");
                }
            }
    }
    
}
