package atividade4;

public interface Imposto {
    public abstract void calculaImposto();
    public abstract void tudo();
}
