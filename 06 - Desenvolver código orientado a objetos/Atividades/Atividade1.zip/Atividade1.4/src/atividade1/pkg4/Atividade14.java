package atividade1.pkg4;

import java.util.ArrayList;
import java.util.Scanner;


public class Atividade14 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
         ArrayList<String> hospedes = new ArrayList<>();
        int opcao;
        while(true){
            System.out.println("Digite 1- cadastrar; 2- pesquisar; 3- sair");
            opcao = entrada.nextInt();
            entrada.nextLine();
            switch(opcao) {
                
                case 1:
                    if(hospedes.size() < 5) {
                        System.out.println(hospedes);
                        System.out.println("Nome do hóspede.");
                        hospedes.add(entrada.nextLine());
                    } else {
                        System.out.println("Máximo de cadastros atingido");
                    }
                    break;
                case 2:
                    System.out.println("Nome do hóspede a ser pesquisado.");
                    String nomeProcurado = entrada.nextLine();
                    int posicao = hospedes.indexOf(nomeProcurado);
                    if (posicao == -1) {
                        System.out.println("Nome não localizado!");
                    } else{
                        System.out.println(nomeProcurado + " foi encontrado no índice " + posicao);
                    }
                    
                    break;
                case 3:
                    System.out.println("TCHAUUUU.");
                    entrada.close();
                    return;
                default:
                    System.out.println("Escolha uma opção válida.");
            }
            
        }
        

    }
    
}
