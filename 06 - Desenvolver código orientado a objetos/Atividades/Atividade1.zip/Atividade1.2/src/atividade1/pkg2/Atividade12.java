package atividade1.pkg2;

import java.util.Scanner;

public class Atividade12 {

    public static void main(String[] args) {
       int[] idade = new int[2];
       String[] nome = new String[2];
       String[] quarto = {"Quarto A", "Quarto B"};
       boolean[] desconto = {false, false};
       Scanner entrada = new Scanner(System.in);
       
       for(int i=0 ;i < nome.length; i++){
           System.out.println("Nome do cliente " + (i + 1));
           nome[i] = entrada.nextLine();
           
           System.out.println("Idade do cliente " + (i + 1));
           idade[i] = entrada.nextInt();
           entrada.nextLine();
           
           if(idade[i] >= 60) {
               desconto[i] = true;
           }
       }
       if(idade[1] > idade[0]) {
           quarto[0] = "Quarto B";
           quarto[1] = "Quarto A";
       }
       System.out.println("----------------------------------");
       for(int i=0 ;i < nome.length; i++){
           String resposta;
           System.out.println(quarto[i]);
           System.out.println("Cliente: " + nome[i]);
           System.out.println("Idade: " + idade[i]);
           resposta = desconto[i] ? nome[i] + " com desconto de 40%\n" :"";
           System.out.println(resposta);           
       }
       entrada.close();
    }
}
