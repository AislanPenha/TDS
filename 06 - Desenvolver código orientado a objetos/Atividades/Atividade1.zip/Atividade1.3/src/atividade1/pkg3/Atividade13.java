package atividade1.pkg3;

import java.util.Scanner;


public class Atividade13 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        float diaria, totalDiaria;
        int idade, totalGratuidade, totalMeia;
        String nome;
        
        totalDiaria = 0;
        totalGratuidade = 0;
        totalMeia = 0;
        
        System.out.println("Digite o valor padrão da diária.");
        diaria = entrada.nextFloat();
        entrada.nextLine();
        while(true){
            System.out.println("Nome do Hóspede (PARE para sair).");
            nome = entrada.nextLine();

            if(nome.equals("PARE")) {
                entrada.close();
                break;
            }
            System.out.println("Idade do Hóspede.");
            idade = entrada.nextInt();
            
            if (idade < 4){
                diaria = 0;
                totalGratuidade ++;
                System.out.println(nome + " possui gratuidade.");
            }else if (idade>80) {
                diaria /= 2;
                totalMeia ++;
                System.out.println(nome + " paga meia.");
            }
            totalDiaria += diaria;
            entrada.nextLine();
            System.out.println("-------------------");
        }

        System.out.println(">>>> RESULTADO <<<<");
        System.out.println("Total de hospedagem: R$" + totalDiaria + "; " + totalGratuidade + " gratuidade(s); " + totalMeia + " meia(s).");
    }
    
}
