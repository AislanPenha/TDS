package atividade1.pkg1;

import java.util.Scanner;

public class Atividade11 {


    public static void main(String[] args) {
       int convidados;
   
       Scanner entrada = new Scanner(System.in);
       
       System.out.println("Digite a quantidade de convidados. ");
       convidados = entrada.nextInt();
       if (convidados > 350 || convidados < 0) {
           System.out.println("Número de convidados inválido. ");
       } else {
           if (convidados <= 150) {
               System.out.println("Use o auditório Alfa.");
           } else {
               if (convidados > 220) {
                   System.out.println("Use o auditório Beta.");
               } else {
                   System.out.println("Use o auditório Alfa.");
                   System.out.println("Inclua mais " + (convidados - 150));
               }
           }
       }
       entrada.close();
        
    }
}
