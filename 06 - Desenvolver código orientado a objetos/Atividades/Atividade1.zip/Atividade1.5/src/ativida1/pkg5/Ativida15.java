package ativida1.pkg5;

import java.util.Scanner;

public class Ativida15 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        boolean[][] andares = new boolean[4][3];
        int andar, quarto;
        String opcao;
         while(true) {
             System.out.println("Informe Andar e Quarto");
             System.out.print("Andar: ");
             andar = entrada.nextInt();
             entrada.nextLine();
             
             System.out.print("Quarto: ");
             quarto = entrada.nextInt();
             entrada.nextLine();
             
             if (andar >= andares.length + 1 || quarto >= andares[0].length + 1 || quarto <= 0 || andar <= 0) {
                 System.out.println(">>>> Quarto e/ou andar inválido. <<<<<");
                 continue;
             }else {
                 andares[andar-1][quarto-1] = true;
             }
             System.out.print("Deseja continuar (S/N): ");
             opcao = entrada.nextLine();
             if(opcao.equals("N")) {
                 System.out.println("TCHAUUUU");
                 entrada.close();
                 break;
             }
         }

         for(int i=0;i<andares.length;i++) {
             System.out.println((i + 1) + " ANDAR: ");
             for(int j=0;j<andares[i].length;j++) {
                 String resp = (andares[i][j]) ? "OCUPADO" : "DESOCUPADO";
                System.out.println(" *quarto [" + (j + 1) + "]: "+ resp);
             }
             System.out.println("");
         }
    }
    
}
