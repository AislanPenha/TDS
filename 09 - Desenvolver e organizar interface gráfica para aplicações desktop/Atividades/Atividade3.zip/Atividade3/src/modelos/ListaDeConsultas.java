package modelos;

import java.util.ArrayList;
import java.util.List;

public class ListaDeConsultas {
    private static final List<Consulta> listaConsultas = new ArrayList<>();
    
    public static void AdicionarConsulta(Consulta consulta){
        listaConsultas.add(consulta);
    }
    public static List<Consulta> lista(){
        return listaConsultas;
    }
}
