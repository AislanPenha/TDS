package modelos;

public class Consulta {
    private Paciente paciente;
    private String data;
    private String observacao;
    private boolean ativo;
    private boolean realizada;

    public Consulta(Paciente paciente, String data, boolean ativo) {
        this.paciente = paciente;
        this.data = data;
        this.ativo = ativo;
        this.realizada = false;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
    
    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
    
    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public boolean isRealizada() {
        return realizada;
    }

    public void setRealizada(boolean realizada) {
        this.realizada = realizada;
    }
    
    
}
