package atividade1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class AcaoBotao implements ActionListener{
    private JTextField valor;
    public AcaoBotao(JTextField txtValor) {
        this.valor = txtValor;
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        Double numero = Double.parseDouble(this.valor.getText());
        if(numero >= 500) {
            Double desconto = -1.0;
            while(desconto < 0 || desconto >100){
                String strDesconto = JOptionPane.showInputDialog("Qual o percentual de desconto (%)");
                desconto = Double.parseDouble(strDesconto);
                if(desconto < 0 || desconto >100){
                    JOptionPane.showMessageDialog(null, "Porcentual inválido",
                   "Digite um valor entre 0 e 100%", JOptionPane.ERROR_MESSAGE);
                }
            }
 
            desconto = numero * desconto/100;
            numero -= desconto;
            JOptionPane.showMessageDialog(null, "O valor com desconto é R$ " + numero);
        } else {
            JOptionPane.showMessageDialog(null, "Digite um valor acima ou igual a R$ 500,00",
               "Numero abaixo de 500", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
