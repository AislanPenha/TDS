package atividade1;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Atividade1 {

    public static void main(String[] args) {
        JFrame tela = new JFrame();
        tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tela.setLocationRelativeTo(null);
        tela.setSize(800, 600);
        
        JLabel lbValor = new JLabel();
        lbValor.setText("Valor de venda (R$)");
        tela.add(lbValor);
        
        JTextField txtValor = new JTextField(15);
        tela.add(txtValor);
        
        JButton btCalcular = new JButton();
        btCalcular.setText("Calcular");
        btCalcular.addActionListener(new AcaoBotao(txtValor));
        tela.add(btCalcular);
        
        tela.setLayout(new FlowLayout());
        tela.setVisible(true);
    }
    
}
