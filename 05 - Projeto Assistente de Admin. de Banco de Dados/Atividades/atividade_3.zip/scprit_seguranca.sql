-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>QUESTÃO 1<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
CREATE USER 'user_funcionario'@'localhost' IDENTIFIED BY '123456';
CREATE USER 'user_dev'@'localhost' IDENTIFIED BY '123456';
CREATE USER 'user_adm'@'localhost' IDENTIFIED BY '123456';

CREATE ROLE 'role_funcionario';
GRANT SELECT ON pi_bd_aislan_penha.* TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE, DELETE ON pi_bd_aislan_penha.horas_extras TO 'role_funcionario';

CREATE ROLE 'role_dev';
GRANT ALL PRIVILEGES ON pi_bd_aislan_penha.* TO 'role_dev';

CREATE ROLE 'role_adm';
GRANT SELECT, INSERT, UPDATE, DELETE ON pi_bd_aislan_penha.* TO 'role_adm';

GRANT 'role_funcionario' TO 'user_funcionario'@'localhost';
GRANT 'role_dev' TO 'user_dev'@'localhost';
GRANT 'role_adm' TO 'user_adm'@'localhost';

SET DEFAULT ROLE 'role_funcionario' TO 'user_funcionario'@'localhost';

FLUSH PRIVILEGES;

-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>QUESTÃO 2<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
CREATE VIEW ultimosDez AS SELECT u.nome, u.email, he.data, TIMEDIFF(he.hora_fim, he.hora_inicio) as HORA_EXTRA FROM  horas_extras he
JOIN usuarios u ON u.id=he.usuario_id ORDER BY he.data DESC LIMIT 10;

CREATE VIEW dadosPrincipaisAtivos AS
SELECT u.nome, u.data_nascimento, u.cpf, u.email, u.salario, he.data, TIMEDIFF(he.hora_fim, he.hora_inicio) as HORAS_EXTRA FROM  horas_extras he
JOIN usuarios u ON u.id=he.usuario_id 
JOIN tipo_status ts ON u.tipoStatus_id=ts.id
WHERE ts.status='a';

-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>QUESTÃO 3<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

-- STORE PROCEDURE
DELIMITER //
CREATE PROCEDURE existeUsuario(id_usuario INT)
BEGIN
	DECLARE id_busca INT;
	SELECT id INTO id_busca FROM usuarios WHERE id=id_usuario;
    iF id_busca IS NULL THEN
		SELECT "NÃO EXISTE ESSE USUÁRIO";
		ELSE
			SELECT u.nome, u.data_nascimento, u.cpf, u.email, u.salario FROM usuarios u WHERE u.id=id_usuario;
    END IF;
END
//
DELIMITER ;
call existeUsuario(22);

-- STORE FUNCTION
DELIMITER //
CREATE FUNCTION calcularIdade(id_usuario INT)
RETURNS INT deterministic
BEGIN
    DECLARE idade INT;
    DECLARE data_atual DATE;
    DECLARE data_nasci DATE;
	SELECT data_nascimento INTO data_nasci FROM usuarios WHERE id=id_usuario;
    SET data_atual = CURDATE();
    SET idade = YEAR(data_atual) - YEAR(data_nasci);
    IF MONTH(data_atual) < MONTH(data_nasci)
        OR (MONTH(data_atual) = MONTH(data_nasci) AND DAY(data_atual) < DAY(data_nasci)) THEN
        SET idade = idade - 1;
    END IF;
    RETURN idade;
END//
DELIMITER ;
SELECT nome, calcularIdade(id) AS idade FROM usuarios;

-- TRIGGER para colocar uma senha MD5
DELIMITER //
CREATE TRIGGER novasenha BEFORE INSERT
ON usuarios
FOR EACH ROW
BEGIN
	SET NEW.senha = md5(NEW.senha);
END //
DELIMITER ;

-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>QUESTÃO 4<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
-- Índice para a chave estrangeira tipoUsuario_id
CREATE INDEX fk_tipousuario_funcionarios_idx ON `pi_bd_aislan_penha`.`usuarios` (`tipoUsuario_id` ASC);
-- Índice para a chave estrangeira tipoStatus_id
CREATE INDEX fk_tipostatus_usuario_idx ON `pi_bd_aislan_penha`.`usuarios` (`tipoStatus_id` ASC);

